<?php defined("BASEPATH") OR exit("No direct script access allowed");
$custom_slug_array["admin"] = "admin";?>